function $(id) {
    return document.getElementById(id);
}
//  按照接口文档的功能 去写具体逻辑
// 功能1: 注册用户名验证： 当用户输入往名字之后 焦点失去之后 触发请求
// 接口地址："api/index.php",
//   请求方式："get"
//   请求参数：
//   	 m: index  进入到指定的index模块
//       a: verifyUserName 进入到对应接口中
//       username: 要验证的用户名
//   返回的数据类型：
//   	json格式：
//     	{
//         code:"返回的信息代码" 
//         			0 =>没有错误 可以注册，
//         			1=> 校验格式有错误，
//         			2=> 已经注册过
//         message: 返回具体的信息
//       }
// 1 获取注册框
var oUserName1 = $('username1');
var oVerifyMsg = $('verifyUserNameMsg');
// 2 获取注册按钮
var oBtnReg = $('btnReg');
var oPassword = $('password');
// 3 登陆的框们
var oBtnLogin = $('btnLogin');
var oUserName2 = $('username2');
var oPassword2 = $('password2');

// 4 获取以下 用户信息框 注册框  登陆框的元素
var userMsg = $('user');
var oReg = $('reg');
var oLogin = $('login');
var oUserInfo = $('userinfo');
// 4 登出验证 退出按钮
var oLogout = $('logout');
// 5 发表留言  按钮  文本域
var oCon = $('content');
var oBtnPost = $('btnPost');
var oList = $('list');

// 6 获取id为showMore里面的a
var moreBtn = $('showMore').getElementsByTagName('a')[0];


// 打开页面 判断用户是否登陆（内部拿cookie uid）
updateAfterLogin()

// 打开页面  应该立即展示所有的用户的留言
// getList
// 接口地址：'api/index.php',
//   	请求方式： 'get',
//     请求参数： 
//     		m:index,
//         a:getList
//         page:当前第几页
//           n ：每页多少条数据
//     返回的数据：
//     	json格式：

// 设置一个全局变量 用来作为第几页的留言
var iPage = 1;

getList();
// 功能6 获取留言列表  （处理一下 加载更多 分页请求）
function getList() {
    ajax({
        url: 'api/index.php',
        data: {
            m: "index",
            a: "getList",
            page: iPage, // 请求第一批
            n: 3 // 每批展示20条留言
        },
        dataType: "json",
        success: function(data) {
            if (data.code === 0) {
                // console.log(oList.innerHTML);

                // 留言成功啦
                // oList 中 循环添加进去所有留言
                var msgList = data.data.list;
                var str = '';
                // 通过字符串循环拼接
                for (var i = 0; i < msgList.length; i++) {

                    str += `<dl class="well">
                    <dt>
                        <strong>${msgList[i].username}</strong> 说 :
                    </dt>
                    <dd class='text'>${msgList[i].content}</dd>
                    <!-- 给当前元素添加一个自定义属性 把它自己的编号存起来 以便于我下一次点击顶的或者踩的时候用 -->
                    <dd class="t" data-cid="${msgList[i].cid}">
                        <a href="javascript:;" class="support">顶(<span>${msgList[i].support}</span>)</a> |
                        <a href="javascript:;" class="oppose">踩(<span>${msgList[i].oppose}</span>)</a>
                    </dd>
                </dl>`;

                }
                oList.innerHTML += str;

                if (iPage === data.data.pages) {
                    // 说明是最后一页
                    moreBtn.style.display = 'none';
                }

            } else if (data.code == 2) {
                // 这里说明没有更多数据啦
                moreBtn.style.display = 'none';
            } else if (data.code === 1) {
                // 根本没有任何留言 
                // 让加载更多按钮隐藏
                moreBtn.style.display = 'none';
                oList.innerHTML = "<p>大家快来抢沙发吧～</p>";
            }
        }
    })

}
// 点击加载更多 按钮 
moreBtn.onclick = function() {
        iPage++;
        getList();
    }
    // 添加焦点失去事件
oUserName1.onblur = function() {
    // 发ajax请求 判断以下当前的用户能否注册
    ajax({
        url: "api/index.php",
        data: {
            m: "index",
            a: "verifyUserName",
            username: this.value
        },
        dataType: 'json',
        success: function(data) {
            console.log(data, typeof data);
            if (!data.code) {
                // 成功 可以注册
                oVerifyMsg.style.color = 'green';
            } else {
                oVerifyMsg.style.color = 'red';
            }
            oVerifyMsg.innerHTML = data.message;
        }
    });
}

// 功能2: 注册验证
// 接口地址："api/index.php",
// 请求方式："post"
//   请求参数：
//   		m: index 
//       a: reg
//       username: 要验证的用户名
//       password: 要验证的密码
//   返回的数据类型：
//   	json格式：
//     	{
//        "message":"注册成功"
//       }
//       {
//         "code":1,
//         "message":"注册失败"
//       }
oBtnReg.onclick = function() {
    ajax({
        method: "post",
        url: "api/index.php",
        data: {
            a: "reg",
            m: "index",
            username: oUserName1.value,
            password: oPassword.value
        },
        dataType: "json",
        success: function(data) {
            console.log(data, typeof data);
            alert(data.message);

            oUserName1.value = '';
            oPassword.value = '';
            oVerifyMsg.innerHTML = '';
        }
    })
}

// 功能3: 登陆验证 
// 接口地址：'api/index.php',
//   	请求方式： 'post',
//     请求参数： 
//     		m:index,
//         a:login
//         username:登陆用户名
//         password:登陆的用户密码
//     返回的数据：
//     	json格式：
//       	{
//           "code":1,
//           "message":"登陆失败"  (登陆用户不存在 /密码不正确)
//         }
//         或
//         {
//           "code": 0,
//           "message":"登陆成功"
//         }

oBtnLogin.onclick = function() {
    ajax({
        method: 'post',
        url: 'api/index.php',
        data: {
            m: "index",
            a: "login",
            username: oUserName2.value,
            password: oPassword2.value
        },
        dataType: "json",
        success: function(data) {
            console.log(data, typeof data);
            // 提示以下用户
            alert(data.message);


            // 如果用户登陆成功之后 后端接口返回的响应数据当中（它
            // 会自动设置好cookie（uid username） 返回到前端  （浏览器会把cookie存储起来））
            // 我们是否显示用户信息框（隐藏注册登陆框） 应该依据于cookie

            // 这个事 登陆之后 要做判断  打开页面也要做用户是否登陆过的判断
            updateAfterLogin()
        }
    })
}

// 功能4: 登出验证
// url: 'api/index.php'
// "get"
// m:index a:logout
// json
oLogout.onclick = function() {
    ajax({
        url: "api/index.php",
        data: {
            m: "index",
            a: "logout"
        },
        dataType: "json",
        success: function(data) {
            // network栏 
            alert(data.message);
            updateAfterLogin();
        }
    })
}

// 功能5:发表留言功能
// url: "api/index.php"
// post
// data: m:index a:send content: 你的留言

oBtnPost.onclick = function() {
    ajax({
        method: "post",
        url: "api/index.php",
        data: {
            m: "index",
            a: "send",
            content: oCon.value
        },
        dataType: "json",
        success: function(data) {
            alert(data.message);
            if (!data.code) {
                // 说明留言成功啦
                // 如果当前发表留言成功 后端数据库已经存起来了
                // 我只要去借用打开页面那一次请求 把所有留言全部拿过来 就已经包含当前留言

                // 调用getList 或者直接刷新页面（自动请求一次getList）
                window.location.reload(); // 页面刷新
            }
        }
    })
}


// 功能7:
// URL：  "api/index.php",
// "get"
// data: m:index  a: doSupport  /  doOppose  cid 留言的编号
// dataType: "json"

// 我们可以委托给父级 代理单击事件  内部通过事件源找触发的元素 合并顶和踩请求

//  事件委托给父级list来代理
oList.onclick = function(e) {
    // 做一个事件对象的兼容性处理
    e = e || event;
    // 通过事件对象去找事件源 
    var target = e.srcElement || e.target;
    console.log(target);

    if (target.nodeName == 'A') {
        // 先判断 当前的事件源 是否是a标签元素
        // 里面区分 这个元素 到底是 顶  还是 踩
        console.log(e);
        if (target.className == 'support') {
            // 这里说明是顶  该放顶的请求
            ajax({
                url: 'api/index.php',
                data: {
                    m: "index",
                    a: "doSupport",
                    cid: target.parentNode.getAttribute('data-cid')
                },
                dataType: 'json',
                success: function(data) {
                    alert(data.message);
                    window.location.reload();
                }
            });
        } else if (target.className == 'oppose') {
            // 这里是踩 该发踩的请求
            ajax({
                url: 'api/index.php',
                data: {
                    m: "index",
                    a: "doOppose",
                    cid: target.parentNode.getAttribute('data-cid')
                },
                dataType: 'json',
                success: function(data) {
                    alert(data.message)
                    window.location.reload();
                }
            });
        }

    }

}









//  这些都是工具方法
function updateAfterLogin() {
    // alert(getCookie("username"))
    // alert(getCookie('uid'));
    if (getCookie('uid')) {
        // 说明当前已经登陆了 
        // 就要把登陆框 注册框隐藏 把用户信息框显示
        userMsg.style.display = 'block';
        oUserInfo.innerHTML = getCookie("username");
        oReg.style.display = 'none';
        oLogin.style.display = 'none';
    } else {
        // 如果判断没有用户登陆 则需要清空信息框隐藏信息框
        // 显示注册框和登陆框
        oReg.style.display = 'block';
        oLogin.style.display = 'block';
        userMsg.style.display = 'none';
        oUserInfo.innerHTML = "";
    }

}

// 封装一个获取cookie的函数
function getCookie(str) {
    // 通过document.cookie去获取当前域名下的所有cookie
    // 因为这是字符串 要字符串操作 处理 
    // 通过split方法 转换为数组
    var arrData = document.cookie.split("; ");
    // 循环所有的cookie数据
    for (var i = 0; i < arrData.length; i++) {
        var smallArr = arrData[i].split("=");
        if (smallArr[0] == str) {
            return decodeURI(smallArr[1]);
        }
    }

}
// 封装一个设置cookie的函数