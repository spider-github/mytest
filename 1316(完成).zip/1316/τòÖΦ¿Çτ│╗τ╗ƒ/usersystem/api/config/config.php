<?php


$_CONFIGS = array(

	'db'	=>	array(
		'db_host'		=>	'localhost',
		'db_port'		=>	'3316',
		'db_user'		=>	'root',
		'db_password'	=>	'root',
		'db_name'		=>	'userSystem',
	),

);