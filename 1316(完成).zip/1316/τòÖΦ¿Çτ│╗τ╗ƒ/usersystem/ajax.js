function ajax(options) {



    //  内部设置一个默认配置
    var defaultSettings = {
        method: options.method || "get", // 'GET'

        url: options.url,
        data: options.data || '',
        success: options.success || null,
        error: options.error || null,
        dataType: options.dataType || 'text'
    }

    var xhr = null;
    try {
        xhr = new XMLHttpRequest();
    } catch (e) {
        xhr = ActiveXObject("Microsoft.XMLHTTP");
    }

    // 写一个小工具函数
    // 把这个传入的数据（这个数据是对象）需要转换为串联的字符串
    // 

    function objToStr(obj) {
        var str = '';
        for (var k in obj) {
            str += k + "=" + obj[k] + "&"
        }
        return str;
    }
    if (defaultSettings.method.toLowerCase() == 'get' && defaultSettings.data) {

        defaultSettings.url += "?" + encodeURI(objToStr(defaultSettings.data)) + (new Date().getTime());
    }

    xhr.open(defaultSettings.method, defaultSettings.url, true);

    if (defaultSettings.method.toLowerCase() == 'post') {
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded')
        xhr.send(objToStr(defaultSettings.data))
    } else {
        xhr.send();
    }

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {

            if (xhr.status === 200) {
                // 成功回调
                // 接收到数据之后要做不一样的逻辑处理

                //  如果后端返回的数据 就是纯文本 字符串
                //  接口文档 提前明确当前这一次请求会预期返回什么数据？ get/post 地址

                var data;

                switch (defaultSettings.dataType) {
                    case 'json':
                        data = JSON.parse(xhr.responseText);
                        break;
                        // 'xml'
                    case 'xml':
                        data = xhr.responseXML;
                        break;
                    case 'text':
                        data = xhr.responseText;
                        break;
                }

                (typeof defaultSettings.success == 'function') && defaultSettings.success(data);
            } else {
                // 404  ....
                //  失败的回调
                // alert('错了 错误信息是' + xhr.status);
                (typeof defaultSettings.error == 'function') && defaultSettings.error(xhr.status)
            }
        }
    }

}