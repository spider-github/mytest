function $(id) {
	return document.getElementById(id);
}
// 1. 获取注册用户名框 密码框, 根据用户名发起ajax请求判断用户名是否存在
iUsername = $('username1') // 触发change事件就会发起ajax请求
verifyUserNameMsg = $('verifyUserNameMsg') // 显示是否能注册的文字
iPassword = $('password') // 触发change事件就会发起ajax请求
iBtnReg = $('btnReg')
// console.log(iUsername)
// console.log(iPassword)

// 获取登录 用户名 和 密码 和 按钮
lGusername = $('username2');
lGpassword = $('password2');
btnLogin = $('btnLogin');
lGuser = $('user');  //登录成显示区
lGuserinfo = $('userinfo')

reg = $('reg')  // 注册框
login = $('login')  // 登录框
lGlogout = $('logout');  // 退出登录

content = $('content')  // 留言
btnPost = $('btnPost')  // 提交留言按钮

// 留言表
list = $('list')
// 加载按钮
showMore = $('showMore')

// 1. 根据鼠标失去焦点来判断用户名是否合法
iUsername.onblur = function() {
	ajax({
		url: "api/index.php",
		data: {
			m: "index",
			a: "verifyUserName",
			username: this.value
		},
		dataType: "json",
		success: function(data) {
			/* console.log(data)
				Object { code: 1, message: "用户名长度不能小于3个或大于16个字符！" }
				Object { code: 0, message: "恭喜你，该用户名可以注册！" }
			*/ // 根据code来判断用户名是否能用
			console.log(data)
			if (!data.code) {
				verifyUserNameMsg.style.color = 'green';
			} else {
				verifyUserNameMsg.style.color = 'red';
			}
			verifyUserNameMsg.innerText = data.message
		}
	})
}  // 出现的bug, 因为之前调试的登录, 存在cookie, 导致一直出现 返回状态码2
// 解决, 清除cookie



// 2. 通过点击注册按钮, 判断用户是否可以注册
iBtnReg.onclick = function(){
	ajax({
		method: "post",
		url:"api/index.php",
		data: {
			a:"reg",
			m:"index",
			username: iUsername.value,
			password: iPassword.value
		},
		dataType: "json",
		success: function(data){
			// console.log(data, typeof data)
			// 注册成功就清除用户输入框和密码输入框和 提示符
			iUsername.value = ''
			iPassword.value = ''
			verifyUserNameMsg.innerText = ''
		}
	})
}

// 3. 登录模块
// 接口地址：'api/index.php',
// 请求方式： 'post',
// m:index,
// a:login
// username:登陆用户名
// password:登陆的用户密码
// 点击提交按钮就触发
btnLogin.onclick = function(){
	ajax({
		methed: "post",
		url: 'api/index.php',
		data:{
			m:'index',
			a:'login',
			username: lGusername.value,
			password: lGpassword.value
		},
		dataType: 'json',
		success: function(data){
			console.log(data)
			// Object { code: 0, message: "登陆成功！" }
			// Object { code: 1, message: "登陆失败！" }
			if(!data.code){
				alert(data.message)
				// lGuser.style.display = 'block';
				// lGuserinfo.innerHTML = lGusername.value;
				// lGlogout.onclick = function(){
				// 	lGuser.style.display = 'none';
				// }
				updateAfterLogin()
				
			}else{
				alert(data.message)
			}
		}
	})
}

// 4. 退出登录
// method: "get",
// url: 'api/index.php',
// m:index ;
// a:logout ;
// dataType: "json"
lGlogout.onclick = function(){
	ajax({
		method: 'get',
		url: 'api/index.php',
		data:{
			m: "index",
			a: 'logout'
		},
		dataType: 'json',
		success: function(data){  // php后端删除cookie
			// console.log(data.message)
			// Object { code: 0, message: "退出成功！" }
			alert(data.message)
			updateAfterLogin()  // 通过判断用户没有cookie来显示登录和注册框
		}
	})
}


// 刷新判断有没有cookie记录
updateAfterLogin()  // 刷新就判断是否有cookie

// 5. 留言模块
// method: "post",
// url: "api/index.php",
// m: "index",
// a: "send",
// content: 留言
btnPost.onclick = function(){

	ajax({
		method: 'post',
		url: 'api/index.php',
		data: {
			m: "index",
			a: "send",
			content: content.value
		},
		dataType: 'json',
		success: function(data){
			// console.log(data)
			// Object { code: 0, message: "留言成功！", data: {…} }
			alert(data.message)
			if(!data.code){
				window.location.reload()
			}
		}
	})
}  // {"code":0,"message":"\u7559\u8a00\u6210\u529f\uff01","data":{"cid":5,"uid":"7","username":"1234","content":"1234546","dateline":1571469116,"support":0,"oppose":0}}, 中文还是ascii码, 是因为忘了写返回类型为json格式

// 6. 获取留言模块
// method: 'get',
// url: 'api/index.php',
// m: "index",
// a: "getList",
// page: iPage, // 请求第一批
// n: 3 // 每批展示留言数
var page = 1
getList()
function getList(){
	ajax({
		method:'get',
		url: 'api/index.php',
		data: {
			m: "index",
			a: "getList",
			page: page, // 请求第一批
			n: 3 // 每批展示留言数
		},
		dataType: 'json',
		success: function(data){
			// console.log(data)
			// Object { code: 0, message: "", data: {…} }
			if(data.code === 0){
				// data.data.list: 是一个数组, 数组的每一项是一个对象>包含所有的数据
				var msg_list = data.data.list
				// console.log(msg_list)
				var str = ''
				for(var i = 0; i< msg_list.length; i++){
					str += `
					<dl class="well">
					    <dt><strong>${msg_list[i].username}</strong> 说 : </dt>
					        <dd class='text'>${msg_list[i].content}</dd>
					        <dd class="t" data-cid="${msg_list[i].cid}"><a href="javascript:;" class="support">顶(<span>${msg_list[i].support}</span>)</a> | <a href="javascript:;" class="oppose">踩(<span>${msg_list[i].oppose}</span>)</a>
							</dd>
					</dl> 
					`
				}
				list.innerHTML += str
				if(page == data.data.pages){  // 当前页码等于页面总数就是最后一页
					showMore.style.display = 'none';
				}
			}
			
			else if(data.code == 2){
				showMore.style.display = 'none';
			}
			else if(data.code == 1){
				showMore.style.display = 'none';
				list.innerHTML = "<p>呵呵, 😒大家快来抢沙发吧～</p>";
			}
			
		}
	})
}
// 点击加载按钮
showMore.onclick = function(){
	page++;
	getList()
}

// 7. 点赞和踩模块
// 利用事件冒泡
// method: "get",
// url："api/index.php",
// m:'index',
// a: 'doSupport'  /  'doOppose'   +> do+类名
// cid: 留言的编号  // 设置自定义属性
// dataType: "json"
list.onclick = function(e){
	e = e || event;
	var target = e.srcElement || e.target;
	// console.log(target) 触发事件的对象
	if(target.nodeName == "A"){
		if(target.className == 'support'){
			// console.log('support')
			ajax({
				method: 'get',
				url: 'api/index.php',
				data: {
					m: 'index',
					a: 'doSupport',
					cid: target.parentNode.getAttribute('data-cid')
				},
				dataType: 'json',
				success: function(data){
					if(!data.code){
						alert(data.message)
						window.location.reload()
					}
				}
			})
		}
		else if(target.className == 'oppose'){
			// console.log('oppose')
			ajax({
				method: 'get',
				url: 'api/index.php',
				data: {
					m: 'index',
					a: 'doOppose',
					cid: target.parentNode.getAttribute('data-cid')
				},
				dataType: 'json',
				success: function(data){
					if(!data.code){
						alert(data.message)
						window.location.reload()
					}
				}
			})
		}
	}
}


// 判断浏览器有没有用户cookie, 有就直接显示用户名, 没有就要登录
function updateAfterLogin(){
	if(getCookie('uid')){
		// 显示登录的用户名和退出按钮
		lGuser.style.display = 'block';
		lGuserinfo.innerHTML = getCookie('username');
		// 隐藏登录框和注册框
		reg.style.display = 'none'
		login.style.display = 'none';
	}else{
		reg.style.display = 'block';
		login.style.display = 'block';
		lGuser.style.display = 'none';
		lGuserinfo.innerHTML = ''
	}
}

// 获取cookie的函数
function getCookie(str){
	// document.cookie  ==> "uid=7; username=1234"
	var all_cookies = document.cookie.split('; ')
	for(var i = 0; i < all_cookies.length; i++){
		// console.log(all_cookies)
		var uCookie = all_cookies[i].split('=')
		if(uCookie[0] == str ){
			return decodeURI(uCookie[1]);  // 返回用户名的值
		}
	}
}  // xx不是一个函数, 