<?php

    header('content-type:text/html;charset=utf-8');
    error_reporting(0);

    $user = $_POST['username'];

    $pass = $_POST['pass'];

    $age = $_POST['age'];




    echo "用户名是{$user}密码是{$pass},年龄是{$age}";


