function ajax(method, url, data, callback) {

    var xhr = null;
    try {
        xhr = new XMLHttpRequest()
    } catch (e) {
        xhr = new ActiveXObject('Microsoft.XMLHTTP');
    }

    if (method == 'get' && data) {
        // "username=zag&age=111&154325123598"
        url += "?" + encodeURI(data) + "&" + (new Date().getTime());
    }

    xhr.open(method, url, true);

    // post还需要设置请求头
    if (method == 'post') {
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded')
        xhr.send(data)
    } else {
        xhr.send()
    }


    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {
            if (xhr.status === 200) {
                // 获取响应内容  数据 需要不同的处理 逻辑
                // console.log(xhr.responseText);
                callback(xhr.responseText)
            } else {
                // 404 ...
                alert("错了错了 错误信息是" + xhr.status)
            }
        }
    }

}