function ajax(options) {



    //  鍐呴儴璁剧疆涓€涓粯璁ら厤缃�
    var defaultSettings = {
        method: options.method || "get", // 'GET'

        url: options.url,
        data: options.data || '',
        success: options.success || null,
        error: options.error || null,
        dataType: options.dataType || 'text'
    }

    var xhr = null;
    try {
        xhr = new XMLHttpRequest();
    } catch (e) {
        xhr = ActiveXObject("Microsoft.XMLHTTP");
    }

    // 鍐欎竴涓皬宸ュ叿鍑芥暟
    // 鎶婅繖涓紶鍏ョ殑鏁版嵁锛堣繖涓暟鎹槸瀵硅薄锛夐渶瑕佽浆鎹负涓茶仈鐨勫瓧绗︿覆
    function objToStr(obj) {
        var str = '';
        for (var k in obj) {
            str += k + "=" + obj[k] + "&"
        }
        return str;
    }
    if (defaultSettings.method.toLowerCase() == 'get' && defaultSettings.data) {

        defaultSettings.url += "?" + encodeURI(objToStr(defaultSettings.data)) + (new Date().getTime());
    }

    xhr.open(defaultSettings.method, defaultSettings.url, true);

    if (defaultSettings.method.toLowerCase() == 'post') {
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded')
        xhr.send(defaultSettings.data)
    } else {
        xhr.send();
    }

    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4) {

            if (xhr.status === 200) {
                // 鎴愬姛鍥炶皟
                // 鎺ユ敹鍒版暟鎹箣鍚庤鍋氫笉涓€鏍风殑閫昏緫澶勭悊

                //  濡傛灉鍚庣杩斿洖鐨勬暟鎹� 灏辨槸绾枃鏈� 瀛楃涓�
                //  鎺ュ彛鏂囨。 鎻愬墠鏄庣‘褰撳墠杩欎竴娆¤姹備細棰勬湡杩斿洖浠€涔堟暟鎹紵 get/post 鍦板潃

                var data;

                switch (defaultSettings.dataType) {
                    case 'json':
                        data = JSON.parse(xhr.responseText);
                        break;
                        // 'xml'
                    case 'xml':
                        data = xhr.responseXML;
                        break;
                    case 'text':
                        data = xhr.responseText;
                        break;
                }

                (typeof defaultSettings.success == 'function') && defaultSettings.success(data);
            } else {
                // 404  ....
                //  澶辫触鐨勫洖璋�
                // alert('閿欎簡 閿欒淇℃伅鏄�' + xhr.status);
                (typeof defaultSettings.error == 'function') && defaultSettings.error(xhr.status)
            }
        }
    }
}

